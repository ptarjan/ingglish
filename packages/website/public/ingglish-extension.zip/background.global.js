"use strict";
(() => {
  // src/background.ts
  var translatedTabs = /* @__PURE__ */ new Set();
  chrome.runtime.onMessage.addListener(
    (message, _sender, sendResponse) => {
      if (message.type === "GET_STATE") {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          const tabId = tabs[0]?.id;
          if (tabId !== void 0) {
            sendResponse({ enabled: translatedTabs.has(tabId) });
          } else {
            sendResponse({ enabled: false });
          }
        });
        return true;
      }
      if (message.type === "TOGGLE") {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          const tabId = tabs[0]?.id;
          if (tabId === void 0) {
            sendResponse({ success: false, error: "No active tab" });
            return;
          }
          const isEnabled = translatedTabs.has(tabId);
          if (isEnabled) {
            translatedTabs.delete(tabId);
            void chrome.tabs.reload(tabId);
            sendResponse({ success: true, enabled: false });
          } else {
            translatedTabs.add(tabId);
            chrome.tabs.sendMessage(tabId, { type: "TRANSLATE" }, (_response) => {
              if (chrome.runtime.lastError) {
                console.error("Error sending message:", chrome.runtime.lastError);
                translatedTabs.delete(tabId);
                sendResponse({ success: false, error: "Could not communicate with page" });
              } else {
                sendResponse({ success: true, enabled: true });
              }
            });
          }
        });
        return true;
      }
      return false;
    }
  );
  chrome.tabs.onRemoved.addListener((tabId) => {
    translatedTabs.delete(tabId);
  });
  chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (changeInfo.status === "loading") {
      translatedTabs.delete(tabId);
    }
  });
  console.log("Ingglish background service worker loaded");
})();
