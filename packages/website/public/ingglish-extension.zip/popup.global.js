"use strict";
(() => {
  // src/popup.ts
  var toggleBtn = document.getElementById("toggle-btn");
  var statusText = document.getElementById("status-text");
  var statusDot = document.getElementById("status-dot");
  if (!toggleBtn || !statusText || !statusDot) {
    throw new Error("Required popup elements not found");
  }
  var isEnabled = false;
  chrome.runtime.sendMessage({ type: "GET_STATE" }, (response) => {
    if (response !== void 0) {
      isEnabled = response.enabled;
      updateUI();
    }
  });
  toggleBtn.addEventListener("click", () => {
    toggleBtn.disabled = true;
    toggleBtn.textContent = "Working...";
    chrome.runtime.sendMessage({ type: "TOGGLE" }, (response) => {
      if (response?.success === true && response.enabled !== void 0) {
        isEnabled = response.enabled;
        updateUI();
      } else {
        statusText.textContent = "Error";
        statusText.style.color = "#ef4444";
        toggleBtn.textContent = "Try Again";
      }
      toggleBtn.disabled = false;
    });
  });
  function updateUI() {
    if (isEnabled) {
      toggleBtn.textContent = "Turn Off";
      toggleBtn.classList.add("active");
      statusText.textContent = "Active";
      statusText.style.color = "#22c55e";
      statusDot.style.background = "#22c55e";
    } else {
      toggleBtn.textContent = "Translate Page";
      toggleBtn.classList.remove("active");
      statusText.textContent = "Off";
      statusText.style.color = "#888";
      statusDot.style.background = "#888";
    }
  }
})();
